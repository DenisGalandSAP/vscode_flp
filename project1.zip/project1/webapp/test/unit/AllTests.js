sap.ui.define([
	"z/project1/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
